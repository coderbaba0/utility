package com.firstfind.app.firstfind

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
